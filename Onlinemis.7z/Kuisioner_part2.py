import requests
from bs4 import BeautifulSoup

url = 'https://login.pens.ac.id/cas/login?service=https%3A%2F%2Fonline.mis.pens.ac.id%2Findex.php%3FLogin%3D1%26halAwal%3D1'
login = 'https://online.mis.pens.ac.id/index.php?Login=1&halAwal=1'

payload = {
    'username': 'madeadit23@me.student.pens.ac.id',
    'password': 'TheDark12345'
}

with requests.session() as s:
    s.get(url, data=payload)
    r = requests.get(login)
    soup = BeautifulSoup(r.content, 'html.parser')
    print(soup.prettify())
    
