import asyncio
import Kebutuhan
from pyppeteer import launch

URL = 'https://online.mis.pens.ac.id/'
login = 'index.php?Login=1&halAwal=1'
logbook = 'mEntry_Logbook_KP1.php'

def main():
    asyncio.get_event_loop().run_until_complete(pepet())

async def pepet():
    print("Prosess !!! ")
    browser = await launch({'headless':True})
    # contex = await browser.createIncogniteBrowserContext()
    page = await browser.newPage()
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0')
    await page.goto(URL + login,{'waitUntil': 'load', 'timeout': 0})
    await page.type('#username', Kebutuhan.usr,{'delay': 5})
    await page.type('#password', Kebutuhan.pwd,{'delay': 5})
    await page.click('.btn-submit')
    await page.waitFor(500)
    await page.goto(URL + logbook, {'waitUntil': 'load', 'timeout': 0})
    await page.waitFor(5000)
    print("Login Sukses !!!")


if __name__ == "__main__":
    main()
    print("Sukses tersimpan Pantekkk !!!")