import asyncio
import Kebutuhan
from pyppeteer import launch

goto = 0

def main():
    asyncio.get_event_loop().run_until_complete(pepet())

URL = 'https://online.mis.pens.ac.id/'
login = 'index.php?Login=1&halAwal=1'
logbook = 'mEntry_Logbook_KP1.php'

# expect_value = '26111'

data = " "

async def pepet():
    print("Prosess !!! ")
    browser = await launch()
    # contex = await browser.createIncogniteBrowserContext()
    page = await browser.newPage()
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0')
    await page.goto(URL + login)
    await page.type('#username', Kebutuhan.usr,{'delay': 5})
    await page.type('#password', Kebutuhan.pwd,{'delay': 5})
    await page.click('.btn-submit')
    await page.waitFor(500)
    await page.goto(URL + logbook, {'waitUntil': 'networkidle2'})
    await page.waitFor(5000)
    print("Login Sukses !!!")

    print("Lagi Ngisi Jam !! ")
    ##Opsi JAM Mulai
    await page.click('#jam_mulai')
    await page.keyboard.down('Control')
    await page.keyboard.press('KeyA')
    await page.keyboard.press('Backspace')
    await page.keyboard.up('Control')
    await page.type('#jam_mulai',Kebutuhan.JamMulai, {'delay': 5})
    await page.waitFor(100)

    ##Opsi Jam Selesai
    await page.click('#jam_selesai')
    await page.keyboard.down('Control')
    await page.keyboard.press('KeyA')
    await page.keyboard.press('Backspace')
    await page.keyboard.up('Control')
    await page.type('#jam_selesai', Kebutuhan.JamSelesai, {'delay': 5})
    await page.waitFor(1000)

    print("lagi ngisi Kegiatan !!!")
    #Opsi Kegiatan
    await page.click('#kegiatan')
    await page.keyboard.down('Control')
    await page.keyboard.press('KeyA')
    await page.keyboard.press('Backspace')
    await page.keyboard.up('Control')
    await page.type('#kegiatan', Kebutuhan.kata,{'delay': 5})
    await page.waitFor(1000)

    ##Opsi Sesuai Kuliah Ya Atau Tidak
    while True:
        SesKul = input("Apakah Sesuai Kuliah ? [Y/N] : ")
        if SesKul == 'Y' or SesKul == 'y':
            await page.click('#sesuai_kuliah1')
            await page.waitFor(100)
            goto = 1
            break
        elif SesKul == 'N' or SesKul == 'n':
            await page.click('#sesuai_kuliah2')
            await page.waitFor(100)
            goto = 0
            break
        else:
            print("Salah INPUT !!! ")
            return True
        
    if goto == 1:
        ##Opsi Matakuliah yg dipilih
        print("\n\n List Mata Kuliah ")
        print(" 1.      VM041103 - Matematika 1 ")
        print(" 2.      VM041104 - Standar Internasional dan K3")
        print(" 3.      VM041105 - Sistem Pengukuran")
        print(" 4.      VM041106 - Mekanika Statika        ")
        print(" 5.      VM041107 - Ilmu Material   ")
        print(" 6.      VM041108 - Rangkaian Listrik 1   ")
        print(" 7.      VM041109 - Praktikum Sistem Pengukuran   ")
        print(" 8.      VM041110 - Praktikum Rangkaian Listrik 1 ")
        print(" 9.      VM041111 - Workshop Gambar Teknik ")
        print(" 10.     VM041112 - Workshop Pemrograman 1  ")
        print(" 11.     VM041201 - Agama  ")
        print(" 12.     VM041202 - Konsep dan Wawasan Teknologi ")
        print(" 13.     VM042101 - Matematika 2 ")
        print(" 14.     VM042102 - Perancangan Mekanika")
        print(" 15.     VM042103 - Mekanika Dinamika   ")
        print(" 16.     VM042104 - Rangkaian Listrik 2        ")
        print(" 17.     VM042105 - Elektronika Analog 1  ")
        print(" 18.     VM042106 - Elektronika Digital 1 ")
        print(" 19.     VM042107 - Elektronika Analog 1   ")
        print(" 20.     M042107  - Rangkaian Listrik 2 ")
        print(" 21.     VM042108 - Praktikum Elektronika Digital 1 ")
        print(" 22.     VM042109 - Workshop Gambar Mesin    ")
        print(" 23.     VM042110 - Bengkel Manufaktur 1  ")
        print(" 24.     VM042111 - Workshop Pemograman 2    ")
        print(" 25.     VM043101 - Kendali Otomatis 1  ")
        print(" 26.     VM043102 - Matematika 3   ")
        print(" 27.     VM043103 - Mekanika Getaran    ")
        print(" 28.     VM043104 - Elektronika Analog 2   ")
        print(" 29.     VM043105 - Elektronika Digital 2  ")
        print(" 30.     VM043106 - Sistem Mikroprosesor  ")
        print(" 31.     VM043107 - Praktikum Sistem Mikroprosesor ")
        print(" 32.     VM043108 - Praktikum Kendali Otomatis 1   ")
        print(" 33.     VM043109 - Elektronika Analog 2      ")
        print(" 34.     VM043109 - Elektronika Digital 2   ")
        print(" 35.     VM043110 - Workshop Bengkel Elektronika  ")
        print(" 36.     VM043111 - Workshop Bengkel Manufaktur 2   ")
        print(" 37.     VM043112 - Workshop Pemograman 3     ")
        print(" 38.     VM044107 - Robotika 1         ")
        print(" 39.     VM044102 - Kendali Otomatis 2 ")
        print(" 40.     VM044103 - Mekanika Fluida   ")
        print(" 41.     VM044104 - Instalasi Industri  ")
        print(" 42.     VM044105 - Elektronika Daya   ")
        print(" 43.     VM044106 - Mikrokontroler dan Sistem Antarmuka  ")
        print(" 44.     VM044107 - Kendali Otomatis 2 ")
        print(" 45.     VM044107 - Robotika 1             ")
        print(" 46.     VM044108 - Praktikum Mikrokontroler dan Sistem Antarmuka   ")
        print(" 47.     VM044109 - Elektronika Daya    ")
        print(" 48.     VM044109 - Instalasi Industri  ")
        print(" 49.     VM044110 - Workshop CNC1     ")
        print(" 50.     VM044111 - Workshop Pengolahan Sinyal   ")
        print(" 51.     VM044112 - Workshop Metode Numerik")
        while True:
            kuliahmata = int(input("Masukan Jenis Matakuliah[1 - 51]: "))
            if kuliahmata == 1:
                data = Kebutuhan.expect_value1
                break
            elif kuliahmata == 2:
                data = Kebutuhan.expect_value2
                break
            elif kuliahmata == 3:
                data = Kebutuhan.expect_value3
                break
            elif kuliahmata == 4:
                data = Kebutuhan.expect_value4
                break
            elif kuliahmata == 5:
                data = Kebutuhan.expect_value5
                break
            elif kuliahmata == 6:
                data = Kebutuhan.expect_value6
                break
            elif kuliahmata == 7:
                data = Kebutuhan.expect_value7
                break
            elif kuliahmata == 8:
                data = Kebutuhan.expect_value8
                break
            elif kuliahmata == 9:
                data = Kebutuhan.expect_value9
                break
            elif kuliahmata == 10:
                data = Kebutuhan.expect_value10
                break
            elif kuliahmata == 11:
                data = Kebutuhan.expect_value11
                break
            elif kuliahmata == 12:
                data = Kebutuhan.expect_value12
                break
            elif kuliahmata == 13:
                data = Kebutuhan.expect_value13
                break
            elif kuliahmata == 14:
                data = Kebutuhan.expect_value14
                break
            elif kuliahmata == 15:
                data = Kebutuhan.expect_value15
                break
            elif kuliahmata == 16:
                data = Kebutuhan.expect_value16
                break
            elif kuliahmata == 17:
                data = Kebutuhan.expect_value17
                break
            elif kuliahmata == 18:
                data = Kebutuhan.expect_value18
                break
            elif kuliahmata == 19:
                data = Kebutuhan.expect_value19
                break
            elif kuliahmata == 20:
                data = Kebutuhan.expect_value20
                break
            elif kuliahmata == 21:
                data = Kebutuhan.expect_value21
                break
            elif kuliahmata == 22:
                data = Kebutuhan.expect_value22
                break
            elif kuliahmata == 23:
                data = Kebutuhan.expect_value23
                break
            elif kuliahmata == 24:
                data = Kebutuhan.expect_value24
                break
            elif kuliahmata == 25:
                data = Kebutuhan.expect_value25
                break
            elif kuliahmata == 26:
                data = Kebutuhan.expect_value26
                break
            elif kuliahmata == 27:
                data = Kebutuhan.expect_value27
                break
            elif kuliahmata == 28:
                data = Kebutuhan.expect_value28
                break
            elif kuliahmata == 29:
                data = Kebutuhan.expect_value29
                break
            elif kuliahmata == 30:
                data = Kebutuhan.expect_value30
                break
            elif kuliahmata == 31:
                data = Kebutuhan.expect_value31
                break
            elif kuliahmata == 32:
                data = Kebutuhan.expect_value32
                break
            elif kuliahmata == 33:
                data = Kebutuhan.expect_value33
                break
            elif kuliahmata == 34:
                data = Kebutuhan.expect_value34
                break
            elif kuliahmata == 35:
                data = Kebutuhan.expect_value35
                break
            elif kuliahmata == 36:
                data = Kebutuhan.expect_value36
                break
            elif kuliahmata == 37:
                data = Kebutuhan.expect_value37
                break
            elif kuliahmata == 38:
                data = Kebutuhan.expect_value38
                break
            elif kuliahmata == 39:
                data = Kebutuhan.expect_value39
                break
            elif kuliahmata == 40:
                data = Kebutuhan.expect_value40
                break
            elif kuliahmata == 41:
                data = Kebutuhan.expect_value41
                break
            elif kuliahmata == 42:
                data = Kebutuhan.expect_value42
                break
            elif kuliahmata == 43:
                data = Kebutuhan.expect_value43
                break
            elif kuliahmata == 44:
                data = Kebutuhan.expect_value44
                break
            elif kuliahmata == 45:
                data = Kebutuhan.expect_value45
                break
            elif kuliahmata == 46:
                data = Kebutuhan.expect_value46
                break
            elif kuliahmata == 47:
                data = Kebutuhan.expect_value47
                break
            elif kuliahmata == 48:
                data = Kebutuhan.expect_value48
                break
            elif kuliahmata == 49:
                data = Kebutuhan.expect_value49
                break
            elif kuliahmata == 50:
                data = Kebutuhan.expect_value50
                break
            elif kuliahmata == 51:
                data = Kebutuhan.expect_value51
                break
            else:
                print("Salah Input !!!")
                return True

        await page.querySelectorEval('#matakuliah', f'element => element.value = "{data}"')
        # await page.querySelectorEval('#matakuliah', 'element => element.value')        

    elif goto == 0:
        #Opsi Setuju
        await page.click('#Setuju')
        await page.waitFor(100)

        #bypass popup
        async def close_dialog(dialog):
            await dialog.accept()
            
        page.on(
            'dialog',
            lambda dialog: asyncio.ensure_future(close_dialog(dialog))
        )

    #SIMPAN
    await page.click('input[value="Simpan"]')
    await page.waitFor(1000)

if __name__ == "__main__":
    main()
    print("Sukses tersimpan Pantekkk !!!")