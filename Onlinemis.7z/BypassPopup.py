import asyncio
from pyppeteer import launch

URL = 'https://the-internet.herokuapp.com/javascript_alerts'

def main():
    asyncio.get_event_loop().run_until_complete(pepet())

async def pepet():
    browser = await launch({
        'headless': False,
        'slowMo': 2
    })
    page = await browser.newPage()

    async def close_dialog(dialog):
        # print(dialog.type)
        print(dialog.message)
        await dialog.accept()

    page.on(
        'dialog',
        lambda dialog: asyncio.ensure_future(close_dialog(dialog))
    )
    await page.goto(URL)
    await page.waitFor(1000)
    await page.click('.example > ul:nth-child(3) > li:nth-child(2) > button:nth-child(1)')
    # elemnt = await page.xpath('//button[@onclick="jsConfirm()"]')
    # await elemnt[0].click()


    # await page.evaluate('() => confirm("I am a JS Confirm")')
    # await pop.click()

    await page.waitFor(10000)

if __name__ == "__main__":
    main()